package trainingMO.Assignment2;

public class Evennumfrom100to200 {

	public static void main(String[] args) {
		
		for (int i=100;i<=200;i++)
		{
			if (i%2==0)
			{System.out.println(i);}
		}

	}

}
