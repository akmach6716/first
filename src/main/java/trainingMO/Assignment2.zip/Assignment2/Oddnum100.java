package trainingMO.Assignment2;

public class Oddnum100 {

	public static void main(String[] args) {
		for(int i=0; i<=100;i++)
		{
			if(i%2!=0)
			{
				System.out.println(i);
			}
		}
	}

}
