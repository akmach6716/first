package trainingMO.assignment1;

public class EvenOrOdd {

	public static void main(String[] args) {
		evenOrOdd(17);
	}
public static void evenOrOdd(int n)
{if(n%2==0)
{System.out.println("Given number is even number");} 
else {
	System.out.println("Given number is Odd");
	}
	
	}
}
