package trainingMO.assignment1;

public class PoitiveOrNegative {

	public static void main(String[] args) {

positiveOrNegative(10);
positiveOrNegative(-10);
	}
public static void positiveOrNegative(int a)
{
	if (a>0)
	{System.out.println(a +": given number is positive");}
	else
	{
		System.out.println(a+": Given number is negative");
	}
	
	}
}
